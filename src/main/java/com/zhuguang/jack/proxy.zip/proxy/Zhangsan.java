package com.zhuguang.jack.proxy;

public class Zhangsan implements People {
    
    public void zhaoduixiang() {
        System.out.println("我是张三，当我需要找对象的时候，我由于工作忙在写代码，所以说我找不到对象！！！");
    }
}
